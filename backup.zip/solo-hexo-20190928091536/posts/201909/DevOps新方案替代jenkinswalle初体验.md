title: DevOps新方案，替代jenkins，walle初体验
date: '2019-09-19 10:50:21'
updated: '2019-09-24 10:53:20'
tags: [walle, jenkins, devOps]
permalink: /articles/2019/09/19/1568861421299.html
---
## 前言
对于目前主流的`devOps`方案，绝大部分都会选择`jenkins`作为打包部署工具。我们今天来用一下一个开源的devOps工具`walle`。

## 安装
`docker-compose`一键安装

## 使用
