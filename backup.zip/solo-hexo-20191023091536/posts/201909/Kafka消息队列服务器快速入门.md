title: Kafka消息队列服务器快速入门
date: '2019-09-24 10:52:46'
updated: '2019-09-24 11:57:16'
tags: [Kafka, java, 服务器]
permalink: /articles/2019/09/24/1569293566124.html
---
## Kafka简介


## Kafka服务器

* Centos7系统安装kafka服务器
* Kafka服务器使用以及术语说明

## Kafka客户端

* Kafka可视化客户端安装及使用
* Java + SpringBoot 简单整合Kafka客户端
* Java kafka客户端简单使用并用可视化客户端验证

## Kafka消息队列企业级项目使用示例

* 消息转发

* 日志处理

* 业务排队异步处理
