title: SpringBoot整合Kafka，实现kafka java客户端与消息队列服务中间件
date: '2019-09-19 09:06:48'
updated: '2019-09-19 09:07:19'
tags: [Kafka, SpringBoot, java, 消息队列]
permalink: /articles/2019/09/19/1568855208050.html
---
## 前言
文章的目标是希望能引导您从零开始实现SpringBoot框架下的Kafka客户端，本文采用中间件的方式，希望能构建一个系统通用的消息队列组件。当然如果这篇文章能让您对kafka有更多的了解，那本人就更深感荣幸。



## kafka简介
