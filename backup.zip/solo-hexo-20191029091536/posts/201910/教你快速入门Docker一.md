title: 教你快速入门Docker（一）
date: '2019-10-13 23:15:12'
updated: '2019-10-29 00:12:43'
tags: [docker, 运维]
permalink: /articles/2019/10/13/1570979712486.html
---
![](https://img.hacpai.com/bing/20181019.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
## 前言
1. 本文适合初级的开发者以及初级运维。
2. 如果没有一点基础，那也没有关系，本文会给你慢慢讲解的。^ ^
3. 欲练此功，**最快的方法是先动手将软件安装好，并简单使用一下**，然后再回头来看这篇文章，效果更佳。

## 什么是Docker？
在讲解`Docker`具体的概念前，我们先来单刀直入的定义下Docker：
1. **`Docker`是一个软件**，英文单词意为**集装箱**，是一种成熟的轻量化类虚拟机技术。
2. 每一个`Docker容器`可以看做一个单独分配有`cpu、内存、硬盘`等设备的小虚拟机。
3. 要初步入门`Docker`，你需要了解它的几个术语：`镜像库`，`镜像`，`容器`。

有使用过`VMware`的同学一定会对「虚拟机」，「镜像」等词非常熟悉，如果你装过windows系统，你也一定见过windows的iso镜像。如果你都听说过，那么恭喜你已经差不多入门了，Docker在这方面跟VMware是类似的，他们都是一款基于指定格式镜像的虚拟机软件。  

其实刚入门的朋友可以把Docker看做一款轻量的虚拟机技术，但实际上Docker并不是虚拟机，想深入了解Docker与VMware的区别，可以看我另一篇文章[Docker和VMware有什么区别？](https://www.baidu.com)，这个话题就点到即止。  

如果你没有使用过VMware也没关系，请看下图：
![docker图解](https://img.hacpai.com/file/2019/10/QQ浏览器截图20191015114423-daa4987f.png)  
可以看到，一台搭载Linux系统（比如CentOS系统）并拥有一定配置的服务器，通过Docker引擎在系统中启动了多个Docker容器，每个容器都被自动分配了一定的配置，它们都可以看做一个独立的CentOS系统，这就是Docker —— 一款轻量级的类虚拟机软件。  

相信你已经对Docker软件有了大概的了解，下面就来说下Docker软件的一些术语：
1. 镜像（Image）：类似于windows系统镜像。**是封装好的Linux系统镜像。**
2. 容器（Container）：基于镜像启动的容器，类似linux系统环境，作用是运行和隔离应用。**如果你学习过Java或者面向对象编程，那镜像可以比作一个类，而容器就是该类的一个具体对象。**
3. 镜像仓库（Repository）：类似Git代码仓库，Docker也有属于自己的镜像库，用来在线存储所有已上传的镜像。用户可以方便的搜索想要的镜像，并通过Docker命令下载到本地。

目前Docker官方的镜像仓库网址是：[https://hub.docker.com](http://www.baidu.com/link?url=Qh-J-JpITKTsxGY8I4NqU225hJsImVKxg9OMKt9YXcDAVimyHl5F4DcoIKNAwlfD)，但是需要梯子，不然很慢很慢。
推荐使用国内的镜像仓库，我用的是阿里云的。注册阿里云，搜素**容器镜像服务**，进入管理后台后，打开镜像中心 -> 镜像搜索，就能看到：
![阿里云镜像仓库.png](https://img.hacpai.com/file/2019/10/阿里云镜像仓库-fc10d365.png)
这样就能搜索自己想要的镜像了。



## 为什么要用Docker？
跟上一节一样，我们也先单刀直入的总结一下为什么要用Docker：
1. 如果你在一台服务器上安装了大量运维软件在CentOS系统中，**Docker能帮你把它做成镜像，让你在任何其他服务器完美复制该服务器状态**。
2. 镜像是Docker的灵魂，在国内外都有大量的**镜像库**供你使用，无论你要安装什么样的服务器，前人已经替你安装好了并打包成镜像了，**你无需再次重复复杂的安装过程，只需到镜像库找相关镜像即可**。

如果上面几点还不足以让你感受到使用Docker带来的好处，那我们可能还得从行业的**痛点**开始讲起。

- 软件更新发布及部署低效，过程繁琐且需要人工介入。
- 环境一致性难以保证。
- 不同环境之间迁移成本太高。

而有了Docker则可以很大程度上解决上述问题，因为Docker的核心是构建镜像，甚至可以做到**Build Once, Run Anywhere（一次构建，多处运行）**，事实上目前流行的**DevOps方案**，绝大部分都是基于Docker，可以说**Docker是现代工程部署方案的基石**。

## Docker快速安装及使用

为了节省您宝贵的时间，请用主流的CentOS系统安装Docker。**Docker目前仅支持CentOS 7以上的64位版本**，如果您没有CentOS环境，请点击下载VMWare虚拟机以及CentOS7镜像，并按文章指引安装。

1. 卸载旧版本  

如果没有安装过Docker，可以略过这一步。如果已安装过Docker，请卸载它们以及相关的依赖项。复制以下命令并执行即可。
```
sudo yum remove docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine
```

2. 安装需要的软件包， yum-util 提供yum-config-manager功能，另外两个是devicemapper驱动依赖的。

```
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```

3. 设置yum源，使用以下命令来设置稳定的仓库。

```
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
```

4. 用yum安装docker。

```
sudo yum install docker-ce docker-ce-cli containerd.io
```

5. Docker 安装完默认未启动，通过以下命令启动Docker。

```
sudo systemctl start docker
```

6. 通过运行 hello-world 镜像来验证是否正确安装了 Docker。

```
sudo docker run hello-world
```

