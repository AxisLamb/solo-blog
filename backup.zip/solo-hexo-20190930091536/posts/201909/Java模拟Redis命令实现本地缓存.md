title: Java模拟Redis命令实现本地缓存
date: '2019-09-12 23:15:25'
updated: '2019-09-24 11:33:50'
tags: [java, redis, 服务器]
permalink: /articles/2019/09/12/1568301325845.html
---
![](https://img.hacpai.com/bing/20180201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Java模拟Redis命令实现本地缓存

测试文章
