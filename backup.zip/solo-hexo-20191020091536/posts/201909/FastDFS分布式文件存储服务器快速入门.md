title: FastDFS分布式文件存储服务器快速入门
date: '2019-09-25 16:15:25'
updated: '2019-09-25 16:15:25'
tags: [fastdfs, java, 服务器]
permalink: /articles/2019/09/25/1569399325484.html
---
## 简介

## FastDFS服务器

* CentOS7安装及单机部署
* Docker一键安装（推荐）
* 服务器日志查看


## FastDFS客户端

* http接口访问服务器存储文件
* Java客户端

## FastDFS服务器在企业级项目的应用示例

* 作为分布式文件存储服务器
	为了更好的说明FastDFS文件服务器的功能，我们先来看看传统的JavaWeb服务器是怎么存储文件的。
	* **`传统服务器`**
		* 用Java原生的文件语法包`java.io.*`进行存储：这种方法直接利用Web应用部署的			服务器的资源，比如Tomcat、Jetty等所在的CentOS服务器的文件系统进行存储。文件将会以CentOS绝对路径的方式记录在Web应用中，如`/usr/local/pics/xxx.jpg`，并随时可以被Web应用使用。
		





* 企业网盘


