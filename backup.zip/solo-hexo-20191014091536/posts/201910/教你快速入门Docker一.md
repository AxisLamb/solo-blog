title: 教你快速入门Docker（一）
date: '2019-10-13 23:15:12'
updated: '2019-10-13 23:15:12'
tags: [docker, 虚拟机, 架构]
permalink: /articles/2019/10/13/1570979712486.html
---
![](https://img.hacpai.com/bing/20181019.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 什么是Docker？



## 为什么要用Docker？



## Docker快速安装及使用




