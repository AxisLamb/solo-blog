title: SpringBoot整合kafka，实现动态创建消费者
date: '2019-09-19 09:16:08'
updated: '2019-09-19 09:16:35'
tags: [Kafka, SpringBoot, java, 消息队列]
permalink: /articles/2019/09/19/1568855768265.html
---
## 前言
众所周知SpringBoot整合kafka，实现消费者的普遍方式是使用`@KafkaListener`注解，并在注解的属性上添加`id, topics`等属性。这样做的话消费者的groupid跟topic几乎是写死的，就算用正则表达式使用topic匹配也会有很大限制，比如topic正则匹配多个topic，由于每个topic都有自己的分区，但是消费者的线程是配置固定的，可能会造成性能问题。那么我们应该怎么解决这个问题呢？下面我们就来实现SpringBoot整合kafka客户端实现的根据需求动态创建消费者的功能。




