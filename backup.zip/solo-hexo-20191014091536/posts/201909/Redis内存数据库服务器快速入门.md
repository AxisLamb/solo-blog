title: Redis内存数据库服务器快速入门
date: '2019-09-24 11:16:54'
updated: '2019-09-24 11:57:10'
tags: [redis, java, 服务器]
permalink: /articles/2019/09/24/1569295014754.html
---
## Redis简介



## Redis 服务器

* Redis 服务器 windows安装及启动

* Redis 服务器支持的数据结构


## Redis 客户端

* Redis自带命令行客户端

* 可视化客户端

* Java客户端

* Python客户端

## Redis服务器企业级运用示例

* 作为系统全局变量的存储和读取的容器
* 手机APP短信验证码登陆
* 待续








