title: Kubernetes服务器最全攻略（一）
date: '2019-09-24 11:35:11'
updated: '2019-09-24 11:35:38'
tags: [kubernetes, k8s, devOps, 服务器]
permalink: /articles/2019/09/24/1569296110875.html
---
Kubernetes服务器最全攻略
